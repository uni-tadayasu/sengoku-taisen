戦国VS / SENGOKU VS — 紹介・掲載用素材
更新日: 2026年11月26日

公式サイト: https://www.kasai-solutions-inc.com/
ゲーム紹介: https://www.kasai-solutions-inc.com/sengoku-vs/
素材と最新情報: https://www.kasai-solutions-inc.com/press/
著作権表記: © KASAI SOLUTIONS

国内向けの日本語紹介文と投稿文、動画用タイトル・説明文、英語の作品概要、
1200×630pxの共有画像5種類、ブランド紋章のSVG・512px PNG、
1363×936pxの実ゲーム画面4枚を収録しています。
ゲームUIと公式ガイドは現在、日本語です。

作品紹介の際は、作品名「戦国VS」、公式URL、著作権表記を添えてください。
images/ は公式イラストによる紹介画像、screenshots/ はローカルデモの
実ゲーム画面です。実画面は清洲城から新しく開始した撮影用デモで、
実プレイヤーの記録を含みません。画面上部のデモ表示を残しています。
人物・地図・家紋などの第三者資料の出典は公式サイトの
作品概要・制作資料を参照してください。

縦型の紹介動画はファイルサイズを抑えるため別配布です。
https://www.kasai-solutions-inc.com/assets/promo/sengoku-vs-intro-ja-20261126.mp4

manifest.jsonには各ファイルのSHA-256と元の公開パスを記載しています。
