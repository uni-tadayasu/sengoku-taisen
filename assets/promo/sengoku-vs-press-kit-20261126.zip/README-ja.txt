戦国VS / SENGOKU VS — 紹介・掲載用素材
更新日: 2026-11-28

公式サイト: https://www.kasai-solutions-inc.com/
ゲーム紹介: https://www.kasai-solutions-inc.com/sengoku-vs/
英語の紹介・始め方: https://www.kasai-solutions-inc.com/en/
素材と最新情報: https://www.kasai-solutions-inc.com/press/
最新の紹介動画: 月夜の城下から、天下地図へ（28秒・日本語／英語字幕）
https://www.youtube.com/watch?v=KFzGnhcSRIA
はじめての3手（36秒・日本語）: https://www.youtube.com/watch?v=j7TEhAidQjw
絵巻で見る戦国VS（24秒・日本語）: https://www.youtube.com/watch?v=NWzewQEJyz0
公開版: Ver.5.16.0
著作権表記: © KASAI SOLUTIONS

国内向けの日本語紹介文と投稿文、動画用タイトル・説明文、英語の作品概要、
1200×630pxの共有画像5種類、ブランド紋章のSVG・512px PNG、
1440×900pxの実ゲーム画面4枚、36秒の「はじめての3手」紹介動画、
動画のポスター・日本語字幕・仕様と素材情報・制作記録を収録しています。
ゲームUIと詳細ガイドは日本語です。英語の紹介・開始ガイドも利用できます。

作品紹介の際は、作品名「戦国VS」、公式URL、著作権表記を添えてください。
images/ は公式イラストによる紹介画像、screenshots/ は撮影用デモ進行を
使用した実ゲーム画面です。城下町はVer.5.9.11の清洲城です。各画像のバージョンと撮影条件は撮影記録を参照してください。
人物・地図・家紋などの第三者資料の出典は公式サイトの
作品概要・制作資料を参照してください。

video/ の36秒動画は、撮影用デモの実ゲーム静止画に移動・拡大を加えた紹介です。
プレイ録画ではありません。全編に撮影用デモであることを表示しています。
動画の画面は過去バージョンのものです。収録するスクリーンショット4枚とは
撮影時期が異なります。詳細はvideo/の制作記録と素材情報を参照してください。

最新の28秒動画は、公式イラストと実ゲーム画面を使った日英字幕つきの紹介です。
容量を抑えるため、動画と字幕は次のURLから別途取得できます。
MP4: https://www.kasai-solutions-inc.com/assets/promo/sengoku-vs-jade-campaign-ja-en-20261127.mp4
日本語字幕: https://www.kasai-solutions-inc.com/assets/promo/sengoku-vs-jade-campaign-ja-en-20261127-ja.vtt
English captions: https://www.kasai-solutions-inc.com/assets/promo/sengoku-vs-jade-campaign-ja-en-20261127-en.vtt

従来の24秒の公式イラスト紹介動画は、容量を抑えるため別配布です。
https://www.kasai-solutions-inc.com/assets/promo/sengoku-vs-intro-ja-20261126.mp4

manifest.jsonには各ファイルのSHA-256と元の公開パスを記載しています。
