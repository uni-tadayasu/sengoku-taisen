戦国VS / SENGOKU VS — 紹介・掲載用素材
更新日: 2026年11月26日

公式サイト: https://www.kasai-solutions-inc.com/
ゲーム紹介: https://www.kasai-solutions-inc.com/sengoku-vs/
素材と最新情報: https://www.kasai-solutions-inc.com/press/
公開済み紹介動画: https://www.youtube.com/watch?v=NWzewQEJyz0
公開版: Ver.5.4.0
著作権表記: © KASAI SOLUTIONS

国内向けの日本語紹介文と投稿文、動画用タイトル・説明文、英語の作品概要、
1200×630pxの共有画像5種類、ブランド紋章のSVG・512px PNG、
1363×936pxの実ゲーム画面4枚、36秒の「はじめての3手」紹介動画、
動画のポスター・日本語字幕・仕様と素材情報・制作記録を収録しています。
ゲームUIと公式ガイドは現在、日本語です。

作品紹介の際は、作品名「戦国VS」、公式URL、著作権表記を添えてください。
images/ は公式イラストによる紹介画像、screenshots/ は撮影用デモ進行を
使用した実ゲーム画面です。城下町は5.1.0の名古屋城で、公開御触書を
表示しています。各画像のバージョンと撮影条件は撮影記録を参照してください。
人物・地図・家紋などの第三者資料の出典は公式サイトの
作品概要・制作資料を参照してください。

video/ の36秒動画は、撮影用デモの実ゲーム静止画に移動・拡大を加えた紹介です。
プレイ録画ではありません。全編に撮影用デモであることを表示しています。

従来の24秒の公式イラスト紹介動画は、容量を抑えるため別配布です。
https://www.kasai-solutions-inc.com/assets/promo/sengoku-vs-intro-ja-20261126.mp4

manifest.jsonには各ファイルのSHA-256と元の公開パスを記載しています。
